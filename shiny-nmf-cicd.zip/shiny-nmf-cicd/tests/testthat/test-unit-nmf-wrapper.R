# TIER 1 -- nmf_factorise() and its helpers
#
# The wrapper is where reproducibility is created, so these tests are the ones
# that make everything downstream trustworthy. They use a seed and assert
# structure and determinism, never a specific loading value: NMF is identified
# only up to scaling and permutation, so a pinned number would be arbitrary.

test_that("count_live_factors counts non-empty columns", {
  expect_equal(count_live_factors(matrix(c(1, 1, 0, 0), 2, 2)), 1)
  expect_equal(count_live_factors(matrix(c(1, 1, 2, 2), 2, 2)), 2)
  expect_equal(count_live_factors(matrix(0, 3, 4)), 0)
  # Below tolerance counts as dead.
  expect_equal(count_live_factors(matrix(c(1e-20, 0, 5, 5), 2, 2)), 1)
})

test_that("reconstruction_error is zero for an exact reconstruction", {
  W <- matrix(c(1, 2, 3, 4), 2, 2)
  H <- matrix(c(1, 0, 0, 1), 2, 2)      # identity, so W %*% H == W
  expect_equal(reconstruction_error(W, W, H), 0)
})

test_that("reconstruction_error is scale free", {
  x <- FIX_SMALL
  W <- matrix(1, 3, 1); H <- matrix(1, 1, 4)
  e1 <- reconstruction_error(x, W, H)
  e2 <- reconstruction_error(x * 1000, W * 1000, H)
  expect_equal(e1, e2, tolerance = 1e-10)
})

test_that("the same seed gives byte-identical results", {
  # The single most important property for CI. Without it, every downstream
  # test is a coin flip and no snapshot can ever be trusted.
  expect_deterministic(function() {
    nmf_factorise(FIX_SMALL, k = 2, seed = 42, maxiter = 100)[c("W", "H")]
  })
})

test_that("different seeds give different results", {
  a <- nmf_factorise(FIX_SMALL, 2, seed = 1, maxiter = 100)
  b <- nmf_factorise(FIX_SMALL, 2, seed = 2, maxiter = 100)
  expect_false(isTRUE(all.equal(a$W, b$W)))
})

test_that("factorising does not disturb the caller's random stream", {
  # nmf_factorise() calls set.seed() internally. Without the save/restore in
  # the wrapper, any sampling elsewhere in the session would silently change
  # depending on whether a factorisation had happened first -- the kind of
  # coupling that makes an unrelated test fail only when the suite runs in a
  # particular order.
  set.seed(99)
  expected <- runif(3)

  set.seed(99)
  invisible(nmf_factorise(FIX_SMALL, 2, seed = 7, maxiter = 50))
  actual <- runif(3)

  expect_equal(actual, expected)
})

test_that("the returned object carries the metadata needed to reproduce it", {
  fit <- nmf_factorise(FIX_SMALL, k = 2, method = "nnmf_mm",
                       maxiter = 120, seed = 5)
  expect_s3_class(fit, "nmf_fit")
  expect_equal(fit$k_requested, 2L)
  expect_equal(fit$method, "nnmf_mm")
  expect_equal(fit$maxiter, 120L)
  expect_equal(fit$seed, 5)
  expect_equal(fit$dim_x, c(3L, 4L))
  expect_true(is.character(fit$nmfn_version))
  expect_true(is.finite(fit$rel_error))
})

test_that("W and H have the documented shapes and are non-negative", {
  for (m in NMF_METHODS) {
    fit <- nmf_factorise(FIX_SMALL, k = 2, method = m, maxiter = 150, seed = 3)
    expect_equal(dim(fit$W), c(3L, 2L), info = m)
    expect_equal(dim(fit$H), c(2L, 4L), info = m)
    expect_true(all(fit$W >= -1e-8), info = m)
    expect_true(all(fit$H >= -1e-8), info = m)
    expect_true(all(is.finite(fit$W)), info = m)
    expect_true(all(is.finite(fit$H)), info = m)
  }
})

test_that("NMFN's console output is suppressed", {
  # With maxiter = 500 the package would print 10 progress lines per call.
  # Inside a Shiny reactive that is log noise on every interaction.
  out <- utils::capture.output(
    fit <- nmf_factorise(FIX_SMALL, 2, maxiter = 500, seed = 1)
  )
  expect_length(out, 0)
  # But the count is retained, so the information is not lost.
  expect_gt(fit$iterations_logged, 0)
})

test_that("a collapsed factor produces a warning rather than silence", {
  # nnmf_als can return all-zero columns. The app needs to know, so the
  # wrapper warns. Finding a case is seed-dependent, so this searches a few
  # seeds and skips if this build's RNG does not produce one -- the invariant
  # that matters is tested in test-contract-nmfn.R.
  warned <- FALSE
  for (s in 1:12) {
    res <- withCallingHandlers(
      {
        f <- nmf_factorise(FIX_SMALL, k = 3, method = "nnmf_als",
                           maxiter = 60, seed = s)
        f
      },
      warning = function(w) {
        if (grepl("carry any weight", conditionMessage(w))) warned <<- TRUE
        invokeRestart("muffleWarning")
      }
    )
    if (warned) {
      expect_lt(res$k_live, res$k_requested)
      break
    }
  }
  if (!warned) {
    skip("no factor collapse across seeds 1-12 on this build")
  }
  expect_true(warned)
})

test_that("validation runs before any computation", {
  # A bad input must fail immediately and cheaply, not after 500 iterations.
  x <- FIX_SMALL; x[1, 1] <- -1
  expect_error(nmf_factorise(x, 2, seed = 1), "negative values")
  expect_error(nmf_factorise(FIX_SMALL, 99, seed = 1), "cannot exceed")
  expect_error(nmf_factorise(FIX_SMALL, 2, method = "bogus", seed = 1),
               "Unknown method")
})

test_that("print.nmf_fit summarises without error", {
  fit <- nmf_factorise(FIX_SMALL, 2, seed = 1, maxiter = 50)
  out <- utils::capture.output(print(fit))
  expect_true(any(grepl("nmf_fit", out)))
  expect_true(any(grepl("rel. error", out, fixed = TRUE)))
})

test_that("omitting the seed is reported as not reproducible", {
  fit <- nmf_factorise(FIX_SMALL, 2, maxiter = 50)      # seed = NULL
  expect_null(fit$seed)
  expect_false(fit_summary(fit)$reproducible)
})
