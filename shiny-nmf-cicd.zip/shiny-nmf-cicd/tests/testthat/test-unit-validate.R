# TIER 1 -- validate_nmf_input()
#
# Pure, instant, exact. Every one of these would fail for exactly one reason,
# which is what makes a red build actionable. This file is the cheapest
# insurance in the suite: it covers the five gaps NMFN leaves open, and none
# of it touches the random number generator.

test_that("a clean matrix passes", {
  expect_true(validate_nmf_input(FIX_SMALL, 2, "nnmf_mm"))
})

test_that("negative values are rejected with a message a user can act on", {
  x <- FIX_SMALL
  x[1, 1] <- -1
  expect_error(validate_nmf_input(x, 2), "negative values")
  # The message names the requirement, not the internals.
  expect_error(validate_nmf_input(x, 2), "all values >= 0")
})

test_that("missing and infinite values are rejected", {
  x_na <- FIX_SMALL; x_na[2, 2] <- NA
  x_inf <- FIX_SMALL; x_inf[2, 2] <- Inf
  x_nan <- FIX_SMALL; x_nan[2, 2] <- NaN

  expect_error(validate_nmf_input(x_na, 2), "missing or infinite")
  expect_error(validate_nmf_input(x_inf, 2), "missing or infinite")
  expect_error(validate_nmf_input(x_nan, 2), "missing or infinite")
})

test_that("an all-zero matrix is rejected", {
  # Guards the unguarded division by sum(x) in NMFN::nnmf_prob, which would
  # otherwise return NaN with no error. Reachable in the app whenever a
  # filter excludes everything.
  expect_error(validate_nmf_input(matrix(0, 3, 3), 2), "sums to zero")
})

test_that("non-matrix and non-numeric input are rejected", {
  expect_error(validate_nmf_input(1:12, 2), "must be a matrix")
  expect_error(validate_nmf_input(as.data.frame(FIX_SMALL), 2),
               "must be a matrix")
  expect_error(validate_nmf_input(matrix(letters[1:6], 2, 3), 1),
               "must be numeric")
})

test_that("k must be a single positive whole number", {
  expect_error(validate_nmf_input(FIX_SMALL, 0), "positive whole number")
  expect_error(validate_nmf_input(FIX_SMALL, -1), "positive whole number")
  expect_error(validate_nmf_input(FIX_SMALL, 2.5), "positive whole number")
  expect_error(validate_nmf_input(FIX_SMALL, NA), "positive whole number")
  expect_error(validate_nmf_input(FIX_SMALL, c(1, 2)), "positive whole number")
})

test_that("k cannot exceed the smaller matrix dimension", {
  # FIX_SMALL is 3x4, so k = 4 is meaningless. NMFN would run anyway.
  expect_error(validate_nmf_input(FIX_SMALL, 4), "cannot exceed")
  expect_true(validate_nmf_input(FIX_SMALL, 3))
})

test_that("an unknown method is rejected rather than silently substituted", {
  # The gap this closes: NMFN::nnmf() dispatches with a bare final `else`
  # that runs nnmf_mm, so a typo'd method name quietly runs a different
  # algorithm from the one requested. Here it fails, and names the options.
  expect_error(validate_nmf_input(FIX_SMALL, 2, "nnmf_als_typo"),
               "Unknown method")
  expect_error(validate_nmf_input(FIX_SMALL, 2, "nnmf_als_typo"),
               "nnmf_mm, nnmf_als, nnmf_prob")
  for (m in NMF_METHODS) {
    expect_true(validate_nmf_input(FIX_SMALL, 2, m))
  }
})

test_that("validation is a pure function of its arguments", {
  # No RNG use, no global state: calling it must not disturb the random
  # stream, or a factorisation elsewhere in the session becomes unreproducible.
  set.seed(1)
  before <- .Random.seed
  validate_nmf_input(FIX_SMALL, 2, "nnmf_mm")
  expect_identical(.Random.seed, before)
})
