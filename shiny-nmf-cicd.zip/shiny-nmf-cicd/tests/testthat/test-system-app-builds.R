# TIER 3a -- does the app still exist?
#
# The cheapest useful test in the suite and the one that catches the most
# common way a Shiny app breaks: a syntax error, a missing library() call, a
# renamed file that source() can no longer find. All of those take the app
# down on restart and none of them are visible until something loads it.
#
# This requires app.R to end with shinyApp(ui, server) rather than runApp().
# With runApp() the call starts a web server and the test hangs until CI times
# out, which looks like an infrastructure fault rather than a code change.

app_dir <- function() {
  # tests/testthat/ -> project root
  normalizePath(testthat::test_path("..", ".."), mustWork = TRUE)
}

test_that("the app object can be built", {
  obj <- shiny::shinyAppDir(app_dir())
  expect_s3_class(obj, "shiny.appobj")
})

test_that("every R/ file sources cleanly in isolation", {
  # Catches a file that only works because something else happened to be
  # loaded first -- a load-order dependency that will bite on a fresh server
  # but not on a developer's warm session.
  files <- list.files(file.path(app_dir(), "R"), pattern = "\\.R$",
                      full.names = TRUE)
  expect_gt(length(files), 0)
  for (f in files) {
    env <- new.env(parent = globalenv())
    err <- tryCatch({
      sys.source(f, envir = env)
      NULL
    }, error = function(e) conditionMessage(e))
    expect_null(err, info = paste(basename(f), "failed to source:", err))
  }
})

test_that("the functions the app calls are all defined", {
  # A rename in R/ that misses one call site shows up here rather than when a
  # user clicks the button.
  for (fn in c("validate_nmf_input", "nmf_factorise", "count_live_factors",
               "reconstruction_error", "tidy_loadings", "top_features",
               "fit_summary", "reconstruct", "demo_matrix",
               "make_structured_matrix", "read_matrix_csv",
               "mod_factors_ui", "mod_factors_server")) {
    expect_true(exists(fn, mode = "function"), info = fn)
  }
})

test_that("the module UI builds and namespaces its inputs", {
  ui <- mod_factors_ui("factors")
  html <- as.character(ui)
  # Namespacing is what stops two instances of a module colliding. If the ns()
  # calls were dropped, the UI would still render and the app would break only
  # when a second instance appeared.
  expect_match(html, "factors-k")
  expect_match(html, "factors-method")
  expect_match(html, "factors-run")
})

test_that("the declared package dependencies are installed", {
  # A missing entry in renv.lock surfaces here with a readable message rather
  # than as an obscure failure midway through another test.
  for (p in c("shiny", "NMFN")) {
    expect_true(requireNamespace(p, quietly = TRUE), info = p)
  }
})
