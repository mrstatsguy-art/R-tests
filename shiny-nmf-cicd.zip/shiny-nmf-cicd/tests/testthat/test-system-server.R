# TIER 3b -- the server logic, driven headlessly
#
# shiny::testServer() runs a module's server function with a mock session: you
# set inputs, read outputs and inspect returned reactives, with no browser, no
# Chrome on the runner and no screenshots to drift.
#
# This is the tier that belongs in a push gate. It covers the reactive wiring
# -- the part Tier 1 cannot reach, because Tier 1 tests pure functions -- and
# still runs in well under a second. The browser tests in
# test-system-browser.R cover what this cannot see (actual rendering, real
# client-server round trips) and are gated behind an env var because they cost
# seconds each and need Chrome installed.

test_that("pressing Run produces a fit from the demo data", {
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 3, method = "nnmf_mm", seed = 1, n_top = 3, run = 1)

    fit <- session$returned$fit()
    expect_s3_class(fit, "nmf_fit")
    expect_equal(fit$k_requested, 3L)
    expect_equal(fit$method, "nnmf_mm")
    expect_equal(fit$seed, 1)
    expect_equal(dim(fit$W), c(10L, 3L))
    expect_equal(dim(fit$H), c(3L, 6L))
  })
})

test_that("changing k changes the shape of the result", {
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 2, method = "nnmf_mm", seed = 1, n_top = 3, run = 1)
    expect_equal(ncol(session$returned$fit()$W), 2L)

    session$setInputs(k = 4, run = 2)
    expect_equal(ncol(session$returned$fit()$W), 4L)
  })
})

test_that("the fit does not refit until Run is pressed again", {
  # eventReactive, not reactive: moving the slider must not kick off a
  # factorisation on every pixel of travel. If this inverts, the app becomes
  # unusable on a large matrix and nothing else would catch it.
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 2, method = "nnmf_mm", seed = 1, n_top = 3, run = 1)
    first <- session$returned$fit()

    session$setInputs(k = 4)          # no new Run
    expect_equal(ncol(session$returned$fit()$W), 2L)   # still the old fit
    expect_identical(session$returned$fit()$W, first$W)

    session$setInputs(run = 2)        # now it refits
    expect_equal(ncol(session$returned$fit()$W), 4L)
  })
})

test_that("the same seed through the UI gives the same answer", {
  # End-to-end reproducibility: the property a user relies on when they send
  # someone a screenshot and a seed.
  grab <- function() {
    out <- NULL
    shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
      session$setInputs(k = 3, method = "nnmf_mm", seed = 123, n_top = 3,
                        run = 1)
      out <<- session$returned$fit()$W
    })
    out
  }
  expect_equal(grab(), grab())
})

test_that("each algorithm is reachable through the UI", {
  for (m in NMF_METHODS) {
    shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
      session$setInputs(k = 2, method = m, seed = 1, n_top = 3, run = 1)
      fit <- session$returned$fit()
      expect_equal(fit$method, m, info = m)
      expect_true(all(fit$W >= -1e-8), info = m)
    })
  }
})

test_that("the status output reports the live factor count and accuracy", {
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 3, method = "nnmf_mm", seed = 1, n_top = 3, run = 1)
    txt <- output$status
    expect_match(txt, "Algorithm:\\s+nnmf_mm")
    expect_match(txt, "Components:\\s+\\d+ live of 3 requested")
    expect_match(txt, "Accuracy:\\s+[0-9.]+%")
    expect_match(txt, "Reproducible: yes")
  })
})

test_that("invalid input is reported in the UI rather than crashing the app", {
  # The matrix is 10x6, so k = 7 exceeds the smaller dimension. The app must
  # say so in the status panel; an uncaught error would grey out the whole
  # page and leave the user with nothing.
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 7, method = "nnmf_mm", seed = 1, n_top = 3)
    expect_false(is.null(session$returned$input_error()))
    expect_match(session$returned$input_error(), "cannot exceed")
    expect_match(output$status, "Cannot run")
  })
})

test_that("a negative value in the data is reported, not factorised", {
  bad <- demo_matrix()
  bad[1, 1] <- -1
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(bad)), {
    session$setInputs(k = 2, method = "nnmf_mm", seed = 1, n_top = 3)
    expect_match(session$returned$input_error(), "negative values")
    expect_match(output$status, "Cannot run")
  })
})

test_that("the top-features table respects n_top and carries real row names", {
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 2, method = "nnmf_mm", seed = 1, n_top = 2, run = 1)
    tbl <- session$returned$top()
    expect_named(tbl, c("factor", "rank", "feature", "loading", "share"))
    expect_lte(nrow(tbl), 2 * 2)
    # Feature labels come from the data, not from generated placeholders.
    expect_true(all(grepl("^feature_", tbl$feature)))

    session$setInputs(n_top = 4)
    expect_lte(nrow(session$returned$top()), 4 * 2)
  })
})

test_that("the plot renders without error for a normal fit and a dead one", {
  shiny::testServer(mod_factors_server, args = list(data_r = reactive(demo_matrix())), {
    session$setInputs(k = 2, method = "nnmf_mm", seed = 1, n_top = 3, run = 1)
    # Touching the output forces the render; an error inside would propagate.
    expect_null(error_message_of(output$loadings_plot))
  })
})
