# TIER 3c -- the real browser
#
# These drive a headless Chrome through shinytest2. They are the only tests
# that exercise what a user actually touches: real HTTP, real client-side
# JavaScript, real rendering. They are also slow (a few seconds each) and need
# Chrome installed on the runner, so they are opt-in:
#
#   RUN_BROWSER_TESTS=true Rscript -e 'testthat::test_dir("tests/testthat")'
#
# The CI config runs them on main and nightly, not on every push.
#
# Deliberately NO screenshot comparison. shinytest2 can snapshot images, but
# font rendering differs between a developer's machine and a Linux runner, so
# image snapshots fail for reasons that have nothing to do with the code --
# the single most common way a Shiny test suite loses its credibility. These
# tests assert on exported VALUES instead, which are platform independent. If
# you do want image snapshots, record them inside the same container CI uses.

app_path <- function() {
  normalizePath(testthat::test_path("..", ".."), mustWork = TRUE)
}

test_that("the app starts in a browser and renders its controls", {
  skip_unless_browser_tests()

  app <- shinytest2::AppDriver$new(
    app_dir = app_path(),
    name = "startup",
    width = 1200, height = 900,
    load_timeout = 60 * 1000
  )
  on.exit(app$stop(), add = TRUE)

  # Reaching an idle state at all means the UI built, every library loaded and
  # the server function ran without error.
  app$wait_for_idle(timeout = 30 * 1000)

  vals <- app$get_values()
  expect_equal(vals$input[["factors-k"]], 3)
  expect_equal(vals$input[["factors-method"]], "nnmf_mm")
})

test_that("pressing Run updates the status panel", {
  skip_unless_browser_tests()

  app <- shinytest2::AppDriver$new(app_dir = app_path(), name = "run",
                                   load_timeout = 60 * 1000)
  on.exit(app$stop(), add = TRUE)

  app$set_inputs(`factors-k` = 2, `factors-seed` = 1)
  app$click("factors-run")
  app$wait_for_idle(timeout = 30 * 1000)

  status <- app$get_value(output = "factors-status")
  expect_match(status, "Algorithm:\\s+nnmf_mm")
  expect_match(status, "live of 2 requested")
  expect_match(status, "Reproducible: yes")
})

test_that("the same seed produces the same status text across sessions", {
  # Reproducibility through the whole stack, including a fresh R process.
  skip_unless_browser_tests()

  read_status <- function() {
    app <- shinytest2::AppDriver$new(app_dir = app_path(), name = "repro",
                                     load_timeout = 60 * 1000)
    on.exit(app$stop(), add = TRUE)
    app$set_inputs(`factors-k` = 3, `factors-seed` = 77)
    app$click("factors-run")
    app$wait_for_idle(timeout = 30 * 1000)
    app$get_value(output = "factors-status")
  }
  expect_equal(read_status(), read_status())
})

test_that("an out-of-range k is reported in the UI, not as a crash", {
  skip_unless_browser_tests()

  app <- shinytest2::AppDriver$new(app_dir = app_path(), name = "bad-k",
                                   load_timeout = 60 * 1000)
  on.exit(app$stop(), add = TRUE)

  # The slider caps at 6 and the demo matrix is 10x6, so every selectable
  # value is valid. Set it out of range directly to prove the server-side
  # guard holds even when the client sends something the UI would not.
  app$set_inputs(`factors-k` = 9, allow_no_input_binding_ = TRUE)
  app$wait_for_idle(timeout = 30 * 1000)

  status <- app$get_value(output = "factors-status")
  expect_match(status, "Cannot run")

  # And the app is still alive afterwards.
  logs <- app$get_logs()
  expect_false(any(grepl("Unhandled error", as.character(logs))))
})

test_that("switching algorithm refits without error", {
  skip_unless_browser_tests()

  app <- shinytest2::AppDriver$new(app_dir = app_path(), name = "methods",
                                   load_timeout = 60 * 1000)
  on.exit(app$stop(), add = TRUE)

  for (m in c("nnmf_mm", "nnmf_als", "nnmf_prob")) {
    app$set_inputs(`factors-method` = m, `factors-k` = 2)
    app$click("factors-run")
    app$wait_for_idle(timeout = 30 * 1000)
    expect_match(app$get_value(output = "factors-status"), m, info = m)
  }
})
