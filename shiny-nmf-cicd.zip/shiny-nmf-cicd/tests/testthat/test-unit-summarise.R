# TIER 1 -- the presentation logic in summarise.R
#
# These functions take a fitted object and produce the data a chart or table
# draws. Because they are pure, the tests build an "nmf_fit" by hand with
# values chosen so every expected number is calculable on paper. No
# factorisation runs here at all, which is why this file executes in
# milliseconds and can never flake.

# A hand-built fit. W has an obvious structure: feature 1 dominates factor 1,
# feature 3 dominates factor 2, and factor 3 is dead.
fake_fit <- function(W = NULL, H = NULL, k = 3, rel_error = 0.02,
                     seed = 1) {
  if (is.null(W)) {
    W <- matrix(c(6, 3, 1,      # factor 1
                  1, 2, 7,      # factor 2
                  0, 0, 0),     # factor 3: dead
                nrow = 3, ncol = 3)
  }
  if (is.null(H)) H <- matrix(1, nrow = 3, ncol = 4)
  structure(
    list(W = W, H = H, k_requested = k,
         k_live = sum(colSums(W) > 1e-10),
         method = "nnmf_mm", maxiter = 500L, seed = seed,
         rel_error = rel_error, dim_x = c(nrow(W), ncol(H)),
         nmfn_version = "2.0.1", iterations_logged = 10L),
    class = "nmf_fit"
  )
}

test_that("tidy_loadings drops dead factors by default", {
  d <- tidy_loadings(fake_fit())
  expect_equal(sort(unique(d$factor)), c(1L, 2L))
  expect_equal(nrow(d), 6)                 # 3 features x 2 live factors
  expect_named(d, c("feature", "factor", "loading"))
})

test_that("tidy_loadings can keep dead factors when asked", {
  d <- tidy_loadings(fake_fit(), drop_dead = FALSE)
  expect_equal(sort(unique(d$factor)), c(1L, 2L, 3L))
  expect_equal(nrow(d), 9)
  expect_true(all(d$loading[d$factor == 3] == 0))
})

test_that("tidy_loadings sorts by factor then descending loading", {
  d <- tidy_loadings(fake_fit())
  f1 <- d[d$factor == 1, ]
  expect_equal(f1$loading, c(6, 3, 1))
  f2 <- d[d$factor == 2, ]
  expect_equal(f2$loading, c(7, 2, 1))
})

test_that("tidy_loadings uses supplied feature names", {
  d <- tidy_loadings(fake_fit(), feature_names = c("alpha", "beta", "gamma"))
  expect_equal(d$feature[d$factor == 1], c("alpha", "beta", "gamma"))
})

test_that("tidy_loadings defaults to generated feature names", {
  d <- tidy_loadings(fake_fit())
  expect_true(all(grepl("^Feature [0-9]+$", d$feature)))
})

test_that("tidy_loadings rejects a wrong-length name vector", {
  expect_error(tidy_loadings(fake_fit(), feature_names = c("only", "two")),
               "must have 3 entries")
})

test_that("tidy_loadings returns an empty frame when every factor is dead", {
  # The app plots this result, so the empty case must have the right shape
  # rather than throwing or returning NULL.
  d <- tidy_loadings(fake_fit(W = matrix(0, 3, 2)))
  expect_equal(nrow(d), 0)
  expect_named(d, c("feature", "factor", "loading"))
  expect_type(d$feature, "character")
  expect_type(d$loading, "double")
})

test_that("top_features ranks and computes shares exactly", {
  t <- top_features(fake_fit(), n_top = 2,
                    feature_names = c("a", "b", "c"))
  expect_equal(nrow(t), 4)                 # 2 live factors x 2 rows
  expect_named(t, c("factor", "rank", "feature", "loading", "share"))

  f1 <- t[t$factor == 1, ]
  expect_equal(f1$feature, c("a", "b"))
  expect_equal(f1$rank, c(1L, 2L))
  expect_equal(f1$loading, c(6, 3))
  # Shares are of the factor's full column total (6 + 3 + 1 = 10), not of the
  # truncated top-n -- so they do not sum to 1 when rows are dropped.
  expect_equal(f1$share, c(0.6, 0.3))
})

test_that("top_features caps at the number of features available", {
  t <- top_features(fake_fit(), n_top = 99)
  expect_equal(nrow(t), 6)                 # 3 features x 2 live factors
})

test_that("top_features rejects a bad n_top", {
  expect_error(top_features(fake_fit(), n_top = 0), "positive whole number")
  expect_error(top_features(fake_fit(), n_top = NA), "positive whole number")
})

test_that("top_features handles an all-dead fit", {
  t <- top_features(fake_fit(W = matrix(0, 3, 2)))
  expect_equal(nrow(t), 0)
  expect_named(t, c("factor", "rank", "feature", "loading", "share"))
})

test_that("fit_summary derives accuracy and quality bands", {
  expect_equal(fit_summary(fake_fit(rel_error = 0.02))$accuracy_pct, 98)
  expect_equal(fit_summary(fake_fit(rel_error = 0.02))$quality, "good")
  expect_equal(fit_summary(fake_fit(rel_error = 0.10))$quality, "fair")
  expect_equal(fit_summary(fake_fit(rel_error = 0.50))$quality, "poor")
})

test_that("fit_summary clamps accuracy to 0-100", {
  # rel_error can exceed 1 for a poor fit, which would give a negative
  # percentage in the UI.
  s <- fit_summary(fake_fit(rel_error = 3))
  expect_gte(s$accuracy_pct, 0)
  expect_lte(s$accuracy_pct, 100)
})

test_that("fit_summary flags collapse and reproducibility", {
  s <- fit_summary(fake_fit())            # 2 live of 3 requested
  expect_true(s$collapsed)
  expect_equal(s$k_live, 2)
  expect_true(s$reproducible)

  s2 <- fit_summary(fake_fit(seed = NULL))
  expect_false(s2$reproducible)
})

test_that("reconstruct multiplies the factors", {
  f <- fake_fit()
  expect_equal(reconstruct(f), f$W %*% f$H)
  expect_equal(dim(reconstruct(f)), c(3L, 4L))
})

test_that("the summarise functions reject objects that are not fits", {
  expect_error(tidy_loadings(list(W = 1)))
  expect_error(fit_summary("not a fit"))
  expect_error(reconstruct(42))
})
