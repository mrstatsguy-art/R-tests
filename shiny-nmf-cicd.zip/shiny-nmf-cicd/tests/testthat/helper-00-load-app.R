# Make the app's own code available to the tests.
#
# This is not a package, so there is no library() call that brings R/ into
# scope. testthat sources helper-*.R files in alphabetical order before any
# test runs, and the 00 prefix puts this one first.
#
# The path is resolved rather than hardcoded because the suite is invoked three
# different ways -- ci/run-tests.R from the project root, tests/testthat.R from
# tests/, and interactively from wherever the developer happens to be -- and a
# relative path that works in one breaks in another.

# Attached, not just namespaced: the Tier 3 tests call reactive() and
# testServer() by bare name, and the app itself does library(shiny), so the
# tests should run against the same loaded state.
library(shiny)

local({
  candidates <- c(
    file.path("..", "..", "R"),                      # from tests/testthat/
    file.path("..", "R"),                            # from tests/
    "R",                                             # from project root
    tryCatch(testthat::test_path("..", "..", "R"),
             error = function(e) NA_character_)
  )
  candidates <- candidates[!is.na(candidates)]

  hit <- NULL
  for (p in candidates) {
    if (dir.exists(p) && length(list.files(p, pattern = "\\.R$")) > 0L) {
      hit <- p
      break
    }
  }
  if (is.null(hit)) {
    stop("Could not locate the app's R/ directory from '", getwd(),
         "'. Run the suite from the project root with ",
         "Rscript ci/run-tests.R", call. = FALSE)
  }

  # Into the global environment, so every test file and every mock Shiny
  # session sees the same definitions the running app would.
  for (f in sort(list.files(hit, pattern = "\\.R$", full.names = TRUE))) {
    sys.source(f, envir = globalenv())
  }
})

if (!requireNamespace("NMFN", quietly = TRUE)) {
  stop("NMFN is not installed. Run renv::restore().", call. = FALSE)
}
