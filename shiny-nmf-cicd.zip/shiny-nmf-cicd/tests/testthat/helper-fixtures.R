# Shared fixtures and helpers.
#
# Tier conventions this suite follows:
#
#   test-unit-*.R      Tier 1. Your code. Fast, exact, no network, no browser.
#                      Must never flake. Gates every push.
#   test-contract-*.R  Tier 2. The NMFN dependency. Invariants only, with
#                      thresholds set from measured worst cases. A failure
#                      here means the dependency changed, not that you broke
#                      something.
#   test-system-*.R    Tier 3. The app end to end. testServer by default;
#                      the browser tests are gated behind an env var.
#
# Run one tier:  testthat::test_dir("tests/testthat", filter = "^unit-")

library(testthat)

# ---------------------------------------------------------------- fixtures

# A tiny matrix with hand-checkable values. Used wherever a test should
# assert an exact number rather than a tolerance.
FIX_SMALL <- matrix(
  c(4, 0, 2,
    0, 6, 3,
    2, 3, 5,
    1, 1, 1),
  nrow = 3, ncol = 4,
  dimnames = list(c("a", "b", "c"), c("s1", "s2", "s3", "s4"))
)

# Thresholds measured across 300 random starts rather than guessed. The
# measured worst case is in the comment so the margin is visible and can be
# re-derived if NMFN changes.
THRESH <- list(
  mm_rank2    = 0.05,   # worst observed 9.9e-05  (margin ~500x)
  als_rank2   = 0.20,   # worst observed 0.057    (margin ~3.5x)
  prob_rank2  = 0.10,   # worst observed 0.030    (margin ~3.3x)
  prob_small  = 0.20,   # worst observed 0.046    (margin ~4.3x)
  prob_mass   = 1e-6    # worst observed 3.6e-16  -- effectively exact
)

# ---------------------------------------------------------------- helpers

# NMFN prints unconditionally. nmf_factorise() already silences it; this is
# for the Tier 2 tests that call the package directly.
quiet <- function(code) {
  utils::capture.output(res <- code)
  res
}

# Run code and return the error message, or NULL if it completed. Avoids
# depending on expect_no_error(), which needs testthat >= 3.1.2.
error_message_of <- function(code) {
  tryCatch({
    utils::capture.output(code)
    NULL
  }, error = function(e) conditionMessage(e))
}

rel_error_of <- function(x, W, H) {
  mean(abs(x - W %*% H)) / mean(abs(x))
}

# Tier 3 browser tests are slow and need Chrome on the runner. Opt in with
# RUN_BROWSER_TESTS=true so a push-gate job never pays for them.
skip_unless_browser_tests <- function() {
  if (!identical(tolower(Sys.getenv("RUN_BROWSER_TESTS")), "true")) {
    skip("set RUN_BROWSER_TESTS=true to run browser tests")
  }
  skip_if_not_installed("shinytest2")
}

# Write lines to a temp CSV and clean it up when the calling test ends.
# withr ships with testthat, so this adds no new dependency.
temp_csv <- function(lines) {
  p <- tempfile(fileext = ".csv")
  writeLines(lines, p)
  withr::defer(unlink(p), envir = parent.frame())
  p
}

# Fail loudly if a test that must be deterministic is not. Runs the
# expression twice and compares.
expect_deterministic <- function(fn) {
  a <- fn()
  b <- fn()
  expect_equal(a, b, info = "same inputs produced different results")
  invisible(a)
}
