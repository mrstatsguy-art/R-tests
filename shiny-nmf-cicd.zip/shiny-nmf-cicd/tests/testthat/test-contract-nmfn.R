# TIER 2 -- the contract with NMFN
#
# These tests do not test your code. They assert the properties of the
# dependency that your code relies on, so that if NMFN ever changes you find
# out from a named test rather than from a user.
#
# A failure here means something different from a Tier 1 failure, and your CI
# should treat it differently: nobody introduced a bug, the ground moved. The
# CI config runs this as its own job for exactly that reason.
#
# Every threshold below was measured across 300 random starts. The worst
# observed value is in the comment, so the margin is visible rather than
# implied. Loose-looking numbers are loose on purpose: an assertion with no
# margin is a scheduled flake.

test_that("the pinned NMFN version is the one installed", {
  # If this fails, read the rest of this file before trusting any of it.
  expect_equal(as.character(utils::packageVersion("NMFN")), "2.0.1")
})

test_that("all three algorithms return list(W, H) with the documented shapes", {
  # The package documentation does not describe the return value at all, so
  # this is the contract as observed from source.
  x <- FIX_SMALL
  for (m in NMF_METHODS) {
    set.seed(1)
    z <- quiet(NMFN::nnmf(x, 2, m, maxiter = 100))
    expect_type(z, "list")
    expect_named(z, c("W", "H"), info = m)
    expect_equal(dim(z$W), c(3L, 2L), info = m)
    expect_equal(dim(z$H), c(2L, 4L), info = m)
  }
})

test_that("factors stay non-negative for non-negative input", {
  # The defining property of the method. Measured: 0 violations in 900 runs.
  x <- FIX_SMALL
  for (m in NMF_METHODS) {
    for (s in c(1, 17, 101)) {
      set.seed(s)
      z <- quiet(NMFN::nnmf(x, 2, m, maxiter = 200))
      expect_true(all(z$W >= -1e-8), info = paste(m, "seed", s))
      expect_true(all(z$H >= -1e-8), info = paste(m, "seed", s))
    }
  }
})

test_that("nnmf_mm recovers a known rank-2 structure", {
  f <- make_structured_matrix(n_features = 6, n_samples = 5, k = 2, seed = 33)
  set.seed(7)
  z <- quiet(NMFN::nnmf(f$x, 2, "nnmf_mm", maxiter = 2000))
  # Worst observed over 300 starts: 9.9e-05. Threshold 0.05 -> ~500x margin.
  expect_lt(rel_error_of(f$x, z$W, z$H), THRESH$mm_rank2)
})

test_that("nnmf_als recovers a known rank-2 structure", {
  f <- make_structured_matrix(n_features = 6, n_samples = 5, k = 2, seed = 33)
  set.seed(7)
  z <- quiet(NMFN::nnmf(f$x, 2, "nnmf_als", maxiter = 200))
  # Worst observed over 300 starts: 0.057. A 0.05 threshold here failed 28
  # times in 300 -- a 9% flake rate. 0.20 gives ~3.5x margin.
  expect_lt(rel_error_of(f$x, z$W, z$H), THRESH$als_rank2)
})

test_that("nnmf_prob recovers a known rank-2 structure", {
  f <- make_structured_matrix(n_features = 6, n_samples = 5, k = 2, seed = 33)
  set.seed(7)
  z <- quiet(NMFN::nnmf(f$x, 2, "nnmf_prob", maxiter = 500))
  # Worst observed over 300 starts: 0.030. Threshold 0.10 -> ~3.3x margin.
  expect_lt(rel_error_of(f$x, z$W, z$H), THRESH$prob_rank2)
})

test_that("nnmf_prob reconstructs on the original, unnormalised scale", {
  # nnmf_prob divides x by sum(x) on the way in and multiplies W by sum(x) on
  # the way out. If a future version left the result on the normalised scale,
  # every number the app displays would be wrong by a factor of sum(x) with no
  # error anywhere. Mass preservation was exact to 3.6e-16 over 300 starts, so
  # this can be asserted sharply rather than loosely.
  set.seed(4)
  z <- quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_prob", maxiter = 400))
  mass_gap <- abs(sum(z$W %*% z$H) - sum(FIX_SMALL)) / sum(FIX_SMALL)
  expect_lt(mass_gap, THRESH$prob_mass)

  # And the same holds after scaling the input by 1000.
  set.seed(4)
  big <- FIX_SMALL * 1000
  zb <- quiet(NMFN::nnmf(big, 2, "nnmf_prob", maxiter = 400))
  expect_lt(abs(sum(zb$W %*% zb$H) - sum(big)) / sum(big), THRESH$prob_mass)
})

test_that("more iterations never make the multiplicative fit worse", {
  # Lee & Seung's monotonicity guarantee. Measured: end/start error ratio
  # never exceeded 0.0053 over 300 starts, so this has enormous margin.
  set.seed(32)
  short <- quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_mm", maxiter = 50))
  set.seed(32)
  long <- quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_mm", maxiter = 500))
  expect_lte(
    sum((FIX_SMALL - long$W %*% long$H)^2),
    sum((FIX_SMALL - short$W %*% short$H)^2) + 1e-9
  )
})

test_that("nnmf_als column sums are always 0 or 1, never between", {
  # The invariant behind the factor-collapse behaviour the wrapper warns
  # about. ALS divides each W column by its own sum, so a live column sums to
  # 1; but a column clipped to all zeros becomes 0 / (0 + eps) = 0 and stays
  # dead. Measured: 0 violations in 900 runs.
  #
  # Asserting all(colSums(W) == 1) looks right and is wrong -- it fails
  # whenever a factor collapses.
  for (s in c(1, 7, 42, 101, 2024)) {
    set.seed(s)
    cs <- colSums(quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_als", maxiter = 60))$W)
    expect_true(
      all(abs(cs - 1) < 1e-8 | abs(cs) < 1e-10),
      info = paste0("seed ", s, ": colSums = ",
                    paste(signif(cs, 8), collapse = ", "))
    )
  }
})

test_that("nnmf_mm and nnmf_als reject non-finite input", {
  x <- FIX_SMALL; x[1, 1] <- NA
  expect_error(NMFN::nnmf_mm(x, 2, 50, 2.2204e-16), "infinite or missing")
  expect_error(NMFN::nnmf_als(x, 2, 50, 2.2204e-16), "infinite or missing")
})

test_that("nnmf_prob does NOT reject non-finite input", {
  # The inconsistency the wrapper exists to paper over: two algorithms raise a
  # clean error, the third returns NaN silently, and which you get depends on
  # a string argument. If a future version adds the guard, this test fails and
  # the wrapper's own check can be simplified.
  x <- FIX_SMALL; x[1, 1] <- NA
  set.seed(1)
  expect_null(error_message_of(NMFN::nnmf_prob(x, 2, 20)))
  set.seed(1)
  z <- quiet(NMFN::nnmf_prob(x, 2, 20))
  expect_true(any(is.na(z$W)) || any(is.na(z$H)))
})

test_that("no algorithm validates non-negativity", {
  # Still true as of 2.0.1. The wrapper's check is the only thing standing
  # between a negative value and a silently wrong answer: the offending cell
  # comes back as roughly zero, with the wrong sign.
  x <- FIX_SMALL; x[1, 1] <- -5
  set.seed(1)
  expect_null(error_message_of(NMFN::nnmf(x, 2, "nnmf_mm", 200)))
  set.seed(1)
  z <- quiet(NMFN::nnmf(x, 2, "nnmf_mm", 200))
  expect_gte((z$W %*% z$H)[1, 1], -1e-6)        # cannot represent it
  expect_gt(abs((z$W %*% z$H)[1, 1] - x[1, 1]), 1)
})

test_that("an unknown method silently runs nnmf_mm", {
  # Proven by identical results under the same seed. This is why
  # validate_nmf_input() checks the method name itself.
  set.seed(1)
  out <- utils::capture.output(z_typo <- NMFN::nnmf(FIX_SMALL, 2, "typo", 50))
  expect_match(paste(out, collapse = " "), "Multiplicative Update")
  set.seed(1)
  z_mm <- quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_mm", 50))
  expect_equal(z_typo$W, z_mm$W)
})

test_that("the convergence check only runs every 50 iterations", {
  # Consequence for the app: maxiter below 50 always runs to completion and
  # can never stop early, and the default maxiter = 1000 prints 20 lines per
  # call. The wrapper caps maxiter at 500 and captures the output.
  set.seed(1)
  short <- utils::capture.output(NMFN::nnmf_mm(FIX_SMALL, 2, 10, 2.2204e-16))
  expect_length(grep("Iter =", short), 0)
  set.seed(1)
  long <- utils::capture.output(NMFN::nnmf_mm(FIX_SMALL, 2, 150, 2.2204e-16))
  expect_gt(length(grep("Iter =", long)), 0)
})

test_that("mpinv satisfies the Moore-Penrose conditions", {
  # Used internally by nnmf_als. Unlike the factorisations this has a single
  # correct answer, so it can be asserted exactly.
  X <- matrix(1:12, 3, 4)                      # rank 2
  M <- NMFN::mpinv(X)
  expect_equal(dim(M), c(4L, 3L))
  expect_equal(X %*% M %*% X, X, tolerance = 1e-8)
  expect_equal(M %*% X %*% M, M, tolerance = 1e-8)

  A <- matrix(c(1, 0, 2, 2, 1, 0, 0, 1, 1), 3, 3, byrow = TRUE)
  expect_equal(NMFN::mpinv(A), solve(A), tolerance = 1e-10)
})

test_that("distance2 is the plain sum of squared differences", {
  a <- matrix(c(1, 2, 3, 4), 2, 2)
  b <- matrix(c(1, 2, 3, 5), 2, 2)
  expect_equal(NMFN::distance2(a, b), 1)
  expect_equal(NMFN::distance2(a, a), 0)
})
