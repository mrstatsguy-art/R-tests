# TIER 1 -- fixtures and CSV parsing
#
# read_matrix_csv() is split out of the Shiny file-input handler precisely so
# it can be tested here, with real temp files, instead of through a browser.
# Upload parsing is where malformed user data enters the app, so it is worth
# covering properly.

test_that("make_structured_matrix builds an exactly rank-k matrix", {
  f <- make_structured_matrix(n_features = 8, n_samples = 5, k = 2,
                              noise = 0, seed = 1)
  expect_equal(dim(f$x), c(8L, 5L))
  expect_equal(dim(f$W_true), c(8L, 2L))
  expect_equal(dim(f$H_true), c(2L, 5L))
  expect_true(all(f$x > 0))
  # Built as W %*% H, so the rank is k by construction.
  expect_equal(qr(f$x)$rank, 2L)
  expect_equal(f$x, f$W_true %*% f$H_true, ignore_attr = TRUE)
})

test_that("make_structured_matrix is reproducible and seed-dependent", {
  a <- make_structured_matrix(seed = 7)$x
  b <- make_structured_matrix(seed = 7)$x
  c2 <- make_structured_matrix(seed = 8)$x
  expect_identical(a, b)
  expect_false(isTRUE(all.equal(a, c2)))
})

test_that("make_structured_matrix leaves the caller's RNG stream alone", {
  set.seed(5)
  expected <- runif(3)
  set.seed(5)
  invisible(make_structured_matrix(seed = 123))
  expect_equal(runif(3), expected)
})

test_that("noise raises the rank above k", {
  f <- make_structured_matrix(n_features = 8, n_samples = 5, k = 2,
                              noise = 0.3, seed = 2)
  expect_gt(qr(f$x)$rank, 2L)
  expect_true(all(f$x > 0))
})

test_that("make_structured_matrix rejects impossible shapes", {
  expect_error(make_structured_matrix(n_features = 2, k = 5))
  expect_error(make_structured_matrix(n_samples = 2, k = 5))
  expect_error(make_structured_matrix(k = 0))
  expect_error(make_structured_matrix(noise = -1))
})

test_that("demo_matrix is non-negative, named and stable", {
  m <- demo_matrix()
  expect_true(is.matrix(m))
  expect_equal(dim(m), c(10L, 6L))
  expect_true(all(m >= 0))
  expect_identical(m, demo_matrix())           # stable across calls
  expect_true(all(grepl("^feature_", rownames(m))))
  expect_true(all(grepl("^sample_", colnames(m))))
})

test_that("the demo matrix passes validation for every offered k", {
  # The UI slider goes to 6 and the matrix is 10x6, so every selectable value
  # must be valid -- otherwise a user can drive the app into an error state
  # just by moving a control.
  m <- demo_matrix()
  for (k in 1:6) {
    expect_true(validate_nmf_input(m, k, "nnmf_mm"), info = paste("k =", k))
  }
})

test_that("read_matrix_csv reads a label column plus numeric columns", {
  p <- temp_csv(c("feature,s1,s2", "a,1,2", "b,3,4"))
  m <- read_matrix_csv(p)
  expect_equal(dim(m), c(2L, 2L))
  expect_equal(rownames(m), c("a", "b"))
  expect_equal(colnames(m), c("s1", "s2"))
  expect_equal(as.numeric(m), c(1, 3, 2, 4))
})

test_that("read_matrix_csv rejects a missing file", {
  expect_error(read_matrix_csv(file.path(tempdir(), "nope-12345.csv")),
               "File not found")
})

test_that("read_matrix_csv rejects a single-column file", {
  p <- temp_csv(c("feature", "a", "b"))
  expect_error(read_matrix_csv(p), "label column")
})

test_that("read_matrix_csv names the offending non-numeric columns", {
  p <- temp_csv(c("feature,s1,s2", "a,1,oops", "b,3,4"))
  expect_error(read_matrix_csv(p), "not numeric")
  expect_error(read_matrix_csv(p), "s2")
})

test_that("a parsed CSV with negative values is caught by validation", {
  # Parsing and validation are separate concerns: read_matrix_csv() returns a
  # matrix, validate_nmf_input() decides whether it can be factorised. The app
  # relies on both, so the seam between them is worth one test.
  p <- temp_csv(c("feature,s1,s2", "a,1,-2", "b,3,4"))
  m <- read_matrix_csv(p)
  expect_true(is.matrix(m))
  expect_error(validate_nmf_input(m, 1), "negative values")
})
