library(testthat)

# Not a package, so load the app's code the way the app does.
for (f in list.files("../R", pattern = "\\.R$", full.names = TRUE)) {
  source(f)
}

test_dir("testthat")
