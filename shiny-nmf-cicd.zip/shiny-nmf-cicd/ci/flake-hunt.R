#!/usr/bin/env Rscript
# Repeat the deterministic tiers many times to catch order- and
# state-dependent flakes, and sweep the dependency contract across seeds.
#
#   Rscript ci/flake-hunt.R 40
#
# Why this exists: every algorithm in NMFN initialises from rnorm(), so a
# tolerance that passes on seed 1 can still fail one run in fifty. The
# thresholds in helper-fixtures.R were set from a 300-start sweep, but the
# sweep used a port of the algorithms rather than NMFN itself. This job
# re-establishes the same margins against the real package, overnight, so a
# drifting threshold is found by a scheduled job rather than by a colleague
# on an unrelated branch.
#
# Any failure here is worth acting on even though the push gate is green: it
# means a test in the gate has a real chance of failing for no reason.

args <- commandArgs(trailingOnly = TRUE)
n_runs <- if (length(args) >= 1) as.integer(args[[1]]) else 25L
stopifnot(!is.na(n_runs), n_runs >= 1L)

suppressPackageStartupMessages(library(testthat))

dir.create("test-results", showWarnings = FALSE)
log_path <- file.path("test-results", "flake-report.txt")
con <- file(log_path, open = "wt")
on.exit(close(con), add = TRUE)

say <- function(...) {
  line <- paste0(...)
  cat(line, "\n", sep = "")
  writeLines(line, con)
}

say("flake hunt: ", n_runs, " repetitions")
say("R:    ", R.version.string)
say("NMFN: ", as.character(utils::packageVersion("NMFN")))
say(strrep("-", 72))

# ---- 1. repeat the deterministic tiers -----------------------------------
# These must pass every single time. A single failure across n runs is a real
# defect, not bad luck, because nothing in them depends on a random draw.
failures <- list()
for (i in seq_len(n_runs)) {
  res <- try(
    testthat::test_dir(
      "tests/testthat",
      filter = "^(unit-|system-(app-builds|server))",
      reporter = "silent",
      stop_on_failure = FALSE
    ),
    silent = TRUE
  )
  if (inherits(res, "try-error")) {
    failures[[length(failures) + 1L]] <- list(run = i, what = "error",
                                              detail = as.character(res))
    next
  }
  df <- as.data.frame(res)
  bad <- df[df$failed > 0 | df$error, , drop = FALSE]
  if (nrow(bad) > 0L) {
    for (j in seq_len(nrow(bad))) {
      failures[[length(failures) + 1L]] <- list(
        run = i, what = "fail",
        detail = paste0(bad$file[j], " :: ", bad$test[j])
      )
    }
  }
  if (i %% 10L == 0L) say("  ... ", i, "/", n_runs, " runs")
}

if (length(failures) == 0L) {
  say("deterministic tiers: ", n_runs, "/", n_runs, " clean")
} else {
  say("deterministic tiers: ", length(failures), " failure(s) across ",
      n_runs, " runs -- THESE ARE FLAKES, fix them")
  tab <- table(vapply(failures, function(f) f$detail, character(1)))
  for (nm in names(sort(tab, decreasing = TRUE))) {
    say("  ", tab[[nm]], "x  ", nm)
  }
}

say(strrep("-", 72))

# ---- 2. sweep the contract thresholds across seeds -----------------------
# Measures the quantity each Tier 2 threshold guards, over many random starts,
# and reports the margin actually achieved against the real package.
source("tests/testthat/helper-fixtures.R")
for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) {
  source(f)
}

rel_err <- function(x, z) mean(abs(x - z$W %*% z$H)) / mean(abs(x))
fx <- make_structured_matrix(n_features = 6, n_samples = 5, k = 2, seed = 33)

sweep <- function(label, threshold, fn, n = n_runs * 4L) {
  vals <- vapply(seq_len(n), function(s) {
    set.seed(s)
    tryCatch(fn(), error = function(e) NA_real_)
  }, numeric(1))
  vals <- vals[!is.na(vals)]
  worst <- max(vals)
  margin <- threshold / worst
  breaches <- sum(vals >= threshold)
  say(sprintf("%-34s p50=%-10.4g worst=%-10.4g thr=%-8.4g margin=%-6.1fx %s",
              label, stats::median(vals), worst, threshold, margin,
              if (breaches == 0L) "ok" else paste0("BREACHED ", breaches, "/",
                                                   length(vals))))
  breaches == 0L
}

ok <- c(
  sweep("mm rank-2 recovery", THRESH$mm_rank2, function() {
    rel_err(fx$x, quiet(NMFN::nnmf(fx$x, 2, "nnmf_mm", 2000)))
  }),
  sweep("als rank-2 recovery", THRESH$als_rank2, function() {
    rel_err(fx$x, quiet(NMFN::nnmf(fx$x, 2, "nnmf_als", 200)))
  }),
  sweep("prob rank-2 recovery", THRESH$prob_rank2, function() {
    rel_err(fx$x, quiet(NMFN::nnmf(fx$x, 2, "nnmf_prob", 500)))
  }),
  sweep("prob mass preservation", THRESH$prob_mass, function() {
    z <- quiet(NMFN::nnmf(FIX_SMALL, 2, "nnmf_prob", 400))
    abs(sum(z$W %*% z$H) - sum(FIX_SMALL)) / sum(FIX_SMALL)
  })
)

say(strrep("-", 72))
say("thresholds holding: ", sum(ok), "/", length(ok))
say("report written to ", log_path)

if (length(failures) > 0L || !all(ok)) {
  quit(status = 1L)
}
