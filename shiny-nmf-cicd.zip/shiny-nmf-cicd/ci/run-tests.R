#!/usr/bin/env Rscript
# Run one tier of the suite and write JUnit XML for CI to pick up.
#
#   Rscript ci/run-tests.R            # unit + system (the push gate)
#   Rscript ci/run-tests.R unit
#   Rscript ci/run-tests.R contract
#   Rscript ci/run-tests.R system
#   Rscript ci/run-tests.R browser
#   Rscript ci/run-tests.R all
#
# Tiers are selected by filename prefix, so adding a test to a tier is just a
# matter of what you call the file. Exits non-zero on failure, which is what
# makes CI go red -- testthat on its own prints failures and exits 0.

args <- commandArgs(trailingOnly = TRUE)
tier <- if (length(args) >= 1) args[[1]] else "gate"

suppressPackageStartupMessages({
  library(testthat)
})

# `%||%` only entered base R in 4.4.0; define it so this runs on older R too.
`%||%` <- function(a, b) if (is.null(a)) b else a

FILTERS <- list(
  unit     = "^unit-",
  contract = "^contract-",
  system   = "^system-(app-builds|server)",   # headless only
  browser  = "^system-browser",
  gate     = "^(unit-|system-(app-builds|server))",
  all      = NULL
)

if (!tier %in% names(FILTERS)) {
  stop("Unknown tier '", tier, "'. One of: ",
       paste(names(FILTERS), collapse = ", "), call. = FALSE)
}

if (identical(tier, "browser")) {
  Sys.setenv(RUN_BROWSER_TESTS = "true")
}

dir.create("test-results", showWarnings = FALSE)
out_file <- file.path("test-results", paste0("junit-", tier, ".xml"))

cat("tier:       ", tier, "\n")
cat("filter:     ", FILTERS[[tier]] %||% "(none)", "\n")
cat("R:          ", R.version.string, "\n")
if (requireNamespace("NMFN", quietly = TRUE)) {
  cat("NMFN:       ", as.character(utils::packageVersion("NMFN")), "\n")
}
cat("junit out:  ", out_file, "\n\n")

# Two reporters: progress for a human reading the log, JUnit for the CI UI to
# render per-test results and link them to the failing line.
reporter <- MultiReporter$new(reporters = list(
  ProgressReporter$new(),
  JunitReporter$new(file = out_file)
))

started <- Sys.time()
results <- test_dir(
  "tests/testthat",
  filter = FILTERS[[tier]],
  reporter = reporter,
  stop_on_failure = FALSE   # let the reporter finish writing the XML first
)
elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))

df <- as.data.frame(results)
n_fail <- sum(df$failed) + sum(df$error)
n_skip <- sum(df$skipped)
n_pass <- sum(df$passed)

cat(sprintf("\n%d passed, %d failed, %d skipped in %.1fs\n",
            n_pass, n_fail, n_skip, elapsed))

# A tier that matched nothing is almost always a typo in a filename, and it
# would otherwise look like a clean pass.
if (nrow(df) == 0L) {
  stop("No test files matched tier '", tier, "'. Check the filename prefixes.",
       call. = FALSE)
}

if (n_fail > 0L) {
  quit(status = 1L)
}
