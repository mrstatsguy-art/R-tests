# Test strategy

86 tests in three tiers. The tiers exist because a red build has to mean
something specific, and the single most useful property of a test suite is
that its failures are diagnosable without reading the code.

```bash
Rscript ci/run-tests.R          # the push gate: unit + system
Rscript ci/run-tests.R unit
Rscript ci/run-tests.R contract
Rscript ci/run-tests.R system
RUN_BROWSER_TESTS=true Rscript ci/run-tests.R browser
Rscript ci/flake-hunt.R 40      # repeat the gate 40x, sweep the thresholds
```

---

## The three tiers

| Tier | Files | Tests | Speed | Needs | Gates a merge? |
|---|---|---:|---|---|---|
| 1 — Unit | `test-unit-*.R` | 50 | milliseconds | nothing | **Yes** |
| 2 — Contract | `test-contract-*.R` | 16 | ~5s | NMFN | **No — advisory** |
| 3 — System | `test-system-*.R` | 20 | ~2s headless, ~30s browser | shiny, Chrome | **Yes** (headless only) |

Tiers are selected by filename prefix, so moving a test between tiers is a
rename. `ci/run-tests.R` fails loudly if a tier matches no files, because a
typo'd prefix would otherwise look like a clean pass.

### Tier 1 — your code

Pure functions: validation, the NMFN wrapper, the summarise/plot-prep logic,
CSV parsing. Exact assertions, no tolerances, no RNG in anything asserted.

**These must never flake.** A single intermittent failure here is a defect, not
bad luck, and `ci/flake-hunt.R` repeats this tier 40 times nightly to prove it.

### Tier 2 — the dependency contract

Asserts the NMFN behaviour the app relies on. **A failure here does not mean
anyone broke anything** — it means the dependency changed. It runs as its own
job with `continue-on-error: true`, and should be left out of branch
protection's required checks.

The distinction matters practically: without it, a vendor behaviour change
blocks every unrelated one-line fix in the repository, and within a week
people learn to merge through red.

### Tier 3 — the app

Split in two, deliberately:

- **Headless** (`test-system-app-builds.R`, `test-system-server.R`) uses
  `shiny::testServer()`, which drives the module server with a mock session —
  no browser, no Chrome, no screenshots. Fast enough for the push gate, and it
  covers the reactive wiring Tier 1 cannot reach.
- **Browser** (`test-system-browser.R`) uses `shinytest2` and a real headless
  Chrome. Opt-in via `RUN_BROWSER_TESTS=true`, run nightly.

`shiny::testServer()` is the most underused tool in R Shiny testing. Most teams
go straight to `shinytest2`, get a slow flaky suite, and conclude Shiny can't
be tested.

---

## Thresholds were measured, not guessed

Every algorithm in NMFN initialises from `rnorm()` with no seed argument, so any
assertion of the form `expect_lt(error, 0.05)` is a coin flip until you know the
distribution behind it. Each candidate threshold was run across 300 random
starts first:

| Assertion | Worst observed | Threshold | Margin |
|---|---:|---:|---:|
| `nnmf_mm` rank-2 recovery | 9.9e-05 | 0.05 | ~500× |
| `nnmf_als` rank-2 recovery | 0.057 | 0.20 | ~3.5× |
| `nnmf_prob` rank-2 recovery | 0.030 | 0.10 | ~3.3× |
| `nnmf_prob` mass preservation | 3.6e-16 | 1e-6 | effectively exact |

Three findings changed the suite:

1. **`nnmf_als` rank-2 recovery at `< 0.05` failed 28 times in 300 — a 9.3%
   flake rate.** That one assertion would have produced a spurious red build
   roughly every eleventh push. Threshold raised to 0.20.
2. **"`k=1` fits worse than `k=2`" failed 3 in 300** and was dropped. Comparing
   fits across different `k` with different random starts is inherently
   unstable — local minima — and no threshold fixes it.
3. **`nnmf_prob` preserves total mass to 3.6e-16**, so that assertion was
   *tightened* from 0.25 to 1e-6. A sharp test that can only fail for a real
   reason is worth more than a loose one.

The numbers came from a numpy port of the three algorithms, because the
environment the suite was written in had no R. Algebraic invariants carry over
exactly; observed frequencies do not, which is why `ci/flake-hunt.R`
re-establishes the same margins against the real package nightly.

---

## Rules this suite follows

**Never assert a specific factorisation value.** If `x ≈ W H`, then for any
positive diagonal `D`, `(W D)(D⁻¹ H)` fits identically — `W` and `H` are
determined only up to scaling and column permutation. A pinned loading would be
one arbitrary point from a continuum of correct answers.

**Always seed, and always restore.** `nmf_factorise()` snapshots and restores
`.Random.seed`, so factorising cannot perturb unrelated sampling elsewhere in
the session. There is a test for this. Without it you get order-dependent
failures, where a test passes alone and fails in the suite.

**Fixtures are synthetic, always.** CI logs, failure output and snapshot files
are readable by anyone with repository access, so no fixture is ever a sample of
real data. `make_structured_matrix()` builds a matrix with known rank *k* and
returns the ground truth alongside it, so tests can check that a factorisation
recovered the structure that was actually planted.

**No image snapshots.** `shinytest2` can compare screenshots, but fonts render
differently on a developer's machine than on a Linux runner, so image snapshots
fail for reasons unrelated to the code. That is the most common way a Shiny
suite loses credibility. These tests assert on exported *values*. If you do want
image snapshots, record them inside the same container CI uses.

**`stop_on_failure` / explicit exit codes.** `testthat` on its own prints
failures and exits 0, so a pipeline using it naively reports green while tests
are red. `ci/run-tests.R` checks the result and calls `quit(status = 1)`.

---

## What the app code does for testability

Three structural choices, which matter more than any test:

1. **Business logic lives in `R/`, not in the server function.** A function
   taking a matrix and returning a data frame is trivial to test. The same logic
   inside a reactive needs a mock session at best and a browser at worst. This
   is why Tier 1 has 50 tests and runs in milliseconds.
2. **The app uses a Shiny module.** `shiny::testServer()` can drive a module
   server directly, which is what makes the headless system tier possible.
3. **Nothing calls `NMFN::nnmf()` directly.** Everything goes through
   `nmf_factorise()`, which adds the validation, seed control, output
   suppression and collapse warning the package lacks. One wrapper, one place to
   test, one place to fix.

### What the wrapper exists to fix

| NMFN behaviour | Consequence | Wrapper's answer |
|---|---|---|
| No non-negativity check | A negative cell comes back as ~0, wrong sign, no warning | `validate_nmf_input()` rejects it |
| `nnmf_prob` has no finite check (the other two do) | Same bad matrix errors cleanly through two methods, returns `NaN` through the third | Rejected before dispatch |
| `nnmf_prob` divides by `sum(x)` unguarded | All-zero input yields `NaN` silently | `sum(x) <= 0` rejected |
| Unknown method falls through to `nnmf_mm` | A typo silently runs a different algorithm | Method name validated |
| `nnmf_als` can return all-zero columns | Fewer usable components than requested | `k_live` reported, warning raised |
| No seed argument | Irreproducible results | `seed=` with RNG save/restore |
| Unconditional `cat()` every 50 iterations | Log flood inside a reactive | Captured, count retained |

---

## CI layout

`ci.yml` on every push — `unit` → `system` (needs `unit`), plus `contract` in
parallel as advisory. `concurrency` cancels superseded runs, which matters with
one self-hosted runner: stale queued jobs otherwise block the work you care
about.

`nightly.yml` at 03:17 — browser tests, plus the flake hunt. The odd minute is
deliberate: scheduled jobs cluster on the hour and get delayed.

Both write JUnit XML to `test-results/` and upload it with
`if: always()`, so a failed run still produces per-test results in the UI
rather than a wall of log text.

**Branch protection:** require `unit` and `system`. Do not require `contract`.

---

## Adding tests

Pick the tier by what a failure would mean:

- Testing a function you wrote? `test-unit-<thing>.R`.
- Testing something NMFN does? `test-contract-nmfn.R`.
- Testing reactive wiring or app startup? `test-system-server.R`.
- Needs a real browser? `test-system-browser.R`, behind
  `skip_unless_browser_tests()`.

If a new test needs a tolerance, measure it across at least 100 random starts
before choosing one, and record the worst observed value in a comment next to
the threshold. An assertion with no stated margin is a scheduled flake.
