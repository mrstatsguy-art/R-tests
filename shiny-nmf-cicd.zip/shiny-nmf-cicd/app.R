# Entry point.
#
# Note the last line: shinyApp(ui, server), NOT runApp(). The Tier 3 smoke
# test loads this file to check the app still builds, and runApp() would start
# a web server and hang the test until CI times out.
#
# Sourcing R/ explicitly rather than relying on auto-loading keeps the load
# order the same in the app, in tests and on the server.

library(shiny)

for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) {
  source(f, local = FALSE)
}

ui <- fluidPage(
  titlePanel("Component Explorer"),
  p("Non-negative matrix factorisation of a feature-by-sample matrix."),
  mod_factors_ui("factors")
)

server <- function(input, output, session) {
  # A reactive so a future version can swap in an uploaded file without the
  # module changing. read_matrix_csv() in R/data.R already handles parsing.
  data_r <- reactive(demo_matrix())
  mod_factors_server("factors", data_r)
}

shinyApp(ui, server)
