"""Measure the flake risk of every tolerance-based assertion.

A CI suite is only worth having if a red build means something. Any assertion
of the form `expect_lt(error, 0.25)` on a randomly-initialised algorithm is a
coin flip unless you know the distribution behind it. This runs each candidate
assertion across many random starts and reports the worst case, so thresholds
can be set with real margin rather than by guessing.
"""
import sys
import numpy as np

sys.path.insert(0, "/tmp/claude-0/-home-claude/040684f3-c5b0-5fb4-bd5f-1cfc3911b3cc/scratchpad")
from verify_claims import nnmf_mm, nnmf_als, nnmf_prob, distance2, EPS_R

N = 300          # random starts per assertion
rng = lambda s: np.random.default_rng(s)

X_SMALL = np.arange(1, 13, dtype=float).reshape(4, 3).T       # 3x4, rank 2


def rel_error(x, W, H):
    return float(np.abs(x - W @ H).mean() / np.abs(x).mean())


def rank2_fixture(seed=33, n=6, m=5, k=2):
    g = rng(seed)
    Wt = np.abs(g.standard_normal((n, k))) + 0.2
    Ht = np.abs(g.standard_normal((k, m))) + 0.2
    return Wt @ Ht


def dense(n=12, m=8, seed=99):
    return np.abs(rng(seed).standard_normal((n, m))) + 0.5


def report(name, values, proposed, direction="lt"):
    v = np.asarray(values, float)
    worst = v.max() if direction == "lt" else v.min()
    if direction == "lt":
        fails = int((v >= proposed).sum())
        margin = proposed / worst if worst > 0 else float("inf")
    else:
        fails = int((v <= proposed).sum())
        margin = worst / proposed if proposed > 0 else float("inf")
    verdict = "SAFE" if fails == 0 else f"FLAKES {fails}/{len(v)}"
    print(f"{name:<52} p50={np.median(v):<11.4g} worst={worst:<11.4g} "
          f"thr={proposed:<9.4g} margin={margin:<7.2f} {verdict}")
    return fails == 0


ok = []

# ---- 1. mm recovers a known rank-2 structure (threshold was 0.05)
Xt = rank2_fixture()
vals = [rel_error(Xt, **{k: v for k, v in
                         nnmf_mm(Xt, 2, 2000, rng=rng(s)).items() if k in ("W", "H")})
        for s in range(N)]
ok.append(report("mm: rank-2 recovery rel_error", vals, 0.05))
ok.append(report("mm: rank-2 recovery rel_error (looser)", vals, 0.20))

# ---- 2. als recovers a known rank-2 structure (threshold was 0.05)
vals = [rel_error(Xt, **{k: v for k, v in
                         nnmf_als(Xt, 2, 200, rng=rng(s)).items() if k in ("W", "H")})
        for s in range(N)]
ok.append(report("als: rank-2 recovery rel_error", vals, 0.05))
ok.append(report("als: rank-2 recovery rel_error (looser)", vals, 0.20))

# ---- 3. prob reconstructs X_SMALL on original scale (threshold was 0.25)
vals, mass = [], []
for s in range(N):
    r = nnmf_prob(X_SMALL, 2, 400, rng=rng(s))
    vals.append(rel_error(X_SMALL, r["W"], r["H"]))
    mass.append(abs((r["W"] @ r["H"]).sum() - X_SMALL.sum()) / X_SMALL.sum())
ok.append(report("prob: X_SMALL rel_error", vals, 0.25))
ok.append(report("prob: mass gap", mass, 0.25))

# ---- 4. prob recovers rank-2 (threshold was 0.10)
vals = [rel_error(Xt, **{k: v for k, v in
                         nnmf_prob(Xt, 2, 500, rng=rng(s)).items() if k in ("W", "H")})
        for s in range(N)]
ok.append(report("prob: rank-2 recovery rel_error", vals, 0.10))
ok.append(report("prob: rank-2 recovery rel_error (looser)", vals, 0.30))

# ---- 5. "a larger k fits at least as well" -- real flake risk (local minima)
D = dense(10, 6)
ratios = []
for s in range(N):
    e1 = distance2(D, (lambda r: r["W"] @ r["H"])(nnmf_mm(D, 1, 400, rng=rng(s))))
    e3 = distance2(D, (lambda r: r["W"] @ r["H"])(nnmf_mm(D, 3, 400, rng=rng(s))))
    ratios.append(e3 / e1)          # want < 1
ok.append(report("mm: err(k=3)/err(k=1) must stay below 1", ratios, 1.0))

# ---- 6. mm end error below start error
r_ = []
for s in range(N):
    g = rng(s)
    W0 = np.abs(g.standard_normal((3, 2)))
    H0 = np.abs(g.standard_normal((2, 4)))
    start = distance2(X_SMALL, W0 @ H0)
    z = nnmf_mm(X_SMALL, 2, 300, rng=rng(s))
    r_.append(distance2(X_SMALL, z["W"] @ z["H"]) / start)
ok.append(report("mm: end/start error must stay below 1", r_, 1.0))

# ---- 7. als live factors on a dense input (asserted >= 3 of 4)
live = []
for s in range(N):
    cs = nnmf_als(dense(12, 8), 4, 60, rng=rng(s))["W"].sum(axis=0)
    live.append(int((cs > 1e-10).sum()))
ok.append(report("als: live factors of 4 on dense input", live, 3, direction="gt"))
print(f"{'':52}  live-factor counts seen: "
      f"{dict(zip(*np.unique(live, return_counts=True)))}")

# ---- 8. prob k=1 fit should be no better than k=2 (flake risk)
diffs = []
for s in range(N):
    e1 = rel_error(X_SMALL, **{k: v for k, v in
                               nnmf_prob(X_SMALL, 1, 200, rng=rng(s)).items()
                               if k in ("W", "H")})
    e2 = rel_error(X_SMALL, **{k: v for k, v in
                               nnmf_prob(X_SMALL, 2, 200, rng=rng(s + 7000)).items()
                               if k in ("W", "H")})
    diffs.append(e1 - e2)           # want >= 0
ok.append(report("prob: err(k=1) - err(k=2) must stay above 0", diffs, 0.0,
                 direction="gt"))

# ---- 9. als column sums strictly in {0,1} across many starts and shapes
viol = 0
for s in range(N):
    for mat, k in ((X_SMALL, 2), (X_SMALL, 3), (dense(9, 6), 3)):
        cs = nnmf_als(mat, k, 60, rng=rng(s))["W"].sum(axis=0)
        if not np.all([np.isclose(c, 0, atol=1e-10) or np.isclose(c, 1, atol=1e-8)
                       for c in cs]):
            viol += 1
print(f"{'als: colSums in {0,1}':<52} violations={viol}/{N*3} "
      f"{'SAFE' if viol == 0 else 'FLAKES'}")
ok.append(viol == 0)

# ---- 10. non-negativity across many starts, all three algorithms
neg = {"mm": 0, "als": 0, "prob": 0}
for s in range(N):
    for nm, fn, kw in (("mm", nnmf_mm, dict(maxiter=300)),
                       ("als", nnmf_als, dict(maxiter=60)),
                       ("prob", nnmf_prob, dict(maxiter=200))):
        z = fn(X_SMALL, 2, rng=rng(s), **kw)
        if z["W"].min() < -1e-8 or z["H"].min() < -1e-8:
            neg[nm] += 1
print(f"{'non-negativity violations (tol 1e-8)':<52} {neg} "
      f"{'SAFE' if sum(neg.values()) == 0 else 'FLAKES'}")
ok.append(sum(neg.values()) == 0)

print()
print(f"{sum(ok)}/{len(ok)} candidate assertions are flake-free at {N} starts")
