# How the thresholds were derived

No R was available where this suite was written, so the three NMFN algorithms
were ported to numpy and every claim checked against the port before being
written as an R assertion.

    python3 verify_claims.py   # 16 invariants
    python3 verify2.py         # characterises the ALS factor collapse
    python3 flake.py           # 300 random starts per tolerance threshold

What they found:

* `verify_claims.py` caught a wrong claim: `colSums(W) == 1` for nnmf_als. The
  real invariant is `colSums(W) in {0, 1}` -- a factor can collapse to zero.
* `verify2.py` measured how often: 0% at k=1, 14% at k=2, 47% at k=3 on a
  rank-2 input; 0% on a dense full-rank one.
* `flake.py` found a 9.3% flake rate in the obvious `als` recovery threshold
  (0.05), a 1% flake in comparing k=1 against k=2 fits, and that `nnmf_prob`
  preserves mass to 3.6e-16 -- so that threshold could be tightened by five
  orders of magnitude instead of loosened.

Not part of the test suite and not needed to run it. They are here so the
reasoning behind each number is checkable, and so the sweep can be repeated if
NMFN changes.

Caveat: the port uses numpy's RNG, not R's. Algebraic invariants carry over
exactly; observed frequencies do not -- which is why ci/flake-hunt.R
re-establishes the same margins against the real package nightly.
