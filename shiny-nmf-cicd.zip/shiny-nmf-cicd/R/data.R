# Data for the app and for tests.
#
# Everything here is synthetic. That is a deliberate constraint, not a
# convenience: CI logs, failure output and snapshot files are all readable by
# anyone with repository access, so no test fixture should ever be a sample of
# real data. Build fixtures with known structure instead -- it also means tests
# can assert against the structure you planted.

#' Build a matrix with a known non-negative rank-k structure
#'
#' The ground truth is returned alongside the matrix, so tests can check
#' whether a factorisation recovered the structure that was actually there
#' rather than just producing a plausible-looking one.
#'
#' @param n_features,n_samples Matrix dimensions.
#' @param k True number of components.
#' @param noise SD of the additive non-negative noise. 0 gives an exactly
#'   rank-k matrix.
#' @param seed Required: fixtures must be reproducible.
#'
#' @return list(x, W_true, H_true, k)
make_structured_matrix <- function(n_features = 12, n_samples = 8, k = 3,
                                   noise = 0, seed = 1) {
  stopifnot(k >= 1, n_features >= k, n_samples >= k, noise >= 0)
  old <- if (exists(".Random.seed", envir = globalenv())) {
    get(".Random.seed", envir = globalenv())
  } else NULL
  on.exit({
    if (!is.null(old)) assign(".Random.seed", old, envir = globalenv())
  }, add = TRUE)
  set.seed(seed)

  W_true <- matrix(abs(stats::rnorm(n_features * k)) + 0.2, n_features, k)
  H_true <- matrix(abs(stats::rnorm(k * n_samples)) + 0.2, k, n_samples)
  x <- W_true %*% H_true
  if (noise > 0) {
    x <- x + abs(stats::rnorm(length(x), sd = noise))
  }
  dimnames(x) <- list(paste0("feature_", seq_len(n_features)),
                      paste0("sample_", seq_len(n_samples)))
  list(x = x, W_true = W_true, H_true = H_true, k = k)
}

#' The demo dataset the app loads on startup
#'
#' Fixed seed, so the app looks the same every time it boots and a system test
#' can assert on its contents.
demo_matrix <- function() {
  make_structured_matrix(n_features = 10, n_samples = 6, k = 3, seed = 42)$x
}

#' Read a user-supplied CSV into a matrix for factorisation
#'
#' Split out from the Shiny file-input handler so the parsing rules can be
#' tested without a browser. Returns a matrix or throws a message meant for
#' an end user.
read_matrix_csv <- function(path) {
  if (!file.exists(path)) {
    stop("File not found.", call. = FALSE)
  }
  df <- utils::read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  if (ncol(df) < 2L) {
    stop("Expected a label column followed by at least one numeric column.",
         call. = FALSE)
  }

  labels <- as.character(df[[1]])
  values <- df[, -1, drop = FALSE]
  non_numeric <- names(values)[!vapply(values, is.numeric, logical(1))]
  if (length(non_numeric) > 0L) {
    stop("These columns are not numeric: ",
         paste(non_numeric, collapse = ", "), ".", call. = FALSE)
  }

  m <- as.matrix(values)
  rownames(m) <- labels
  m
}
