# Business logic: turning a factorisation into something a chart can draw.
#
# These are plain functions of plain data -- no reactives, no Shiny, no
# randomness. That is deliberate: it is what lets Tier 1 assert exact values
# and run in milliseconds. Logic left inside a server function can only be
# reached through a browser or a mock session, which is an order of magnitude
# slower and far harder to debug when it fails in CI.

#' Tidy the factor loadings for plotting
#'
#' @param fit An "nmf_fit" from nmf_factorise().
#' @param feature_names Optional row labels; defaults to Feature 1..n.
#' @param drop_dead Drop factors whose loadings are all zero.
#'
#' @return A data frame with one row per feature-factor pair, columns
#'   feature, factor, loading. Sorted by factor then descending loading.
tidy_loadings <- function(fit, feature_names = NULL, drop_dead = TRUE) {
  stopifnot(inherits(fit, "nmf_fit"))
  W <- fit$W
  n <- nrow(W)

  if (is.null(feature_names)) {
    feature_names <- paste("Feature", seq_len(n))
  }
  if (length(feature_names) != n) {
    stop("`feature_names` must have ", n, " entries, not ",
         length(feature_names), ".", call. = FALSE)
  }

  keep <- if (drop_dead) which(colSums(W) > 1e-10) else seq_len(ncol(W))
  if (length(keep) == 0L) {
    return(data.frame(feature = character(0), factor = integer(0),
                      loading = numeric(0), stringsAsFactors = FALSE))
  }

  out <- data.frame(
    feature = rep(feature_names, times = length(keep)),
    factor  = rep(keep, each = n),
    loading = as.numeric(W[, keep, drop = FALSE]),
    stringsAsFactors = FALSE
  )
  out[order(out$factor, -out$loading), , drop = FALSE] -> out
  rownames(out) <- NULL
  out
}

#' The features contributing most to each factor
#'
#' What the app shows as "what is this component made of".
#'
#' @param n_top How many features per factor.
#' @return A data frame with factor, rank, feature, loading, share, where
#'   share is the loading as a proportion of that factor's total.
top_features <- function(fit, n_top = 3, feature_names = NULL) {
  loadings <- tidy_loadings(fit, feature_names, drop_dead = TRUE)
  if (nrow(loadings) == 0L) {
    return(data.frame(factor = integer(0), rank = integer(0),
                      feature = character(0), loading = numeric(0),
                      share = numeric(0), stringsAsFactors = FALSE))
  }
  if (length(n_top) != 1L || is.na(n_top) || n_top < 1L) {
    stop("`n_top` must be a single positive whole number.", call. = FALSE)
  }

  parts <- lapply(split(loadings, loadings$factor), function(df) {
    df <- df[order(-df$loading), , drop = FALSE]
    total <- sum(df$loading)
    df <- utils::head(df, n_top)
    data.frame(
      factor  = df$factor,
      rank    = seq_len(nrow(df)),
      feature = df$feature,
      loading = df$loading,
      share   = if (total > 0) df$loading / total else rep(0, nrow(df)),
      stringsAsFactors = FALSE
    )
  })
  out <- do.call(rbind, parts)
  rownames(out) <- NULL
  out[order(out$factor, out$rank), , drop = FALSE]
}

#' A one-line summary of fit quality, for the app's status bar
#'
#' Returns a list rather than a formatted string so the wording lives in the
#' UI and the numbers can be asserted exactly in tests.
fit_summary <- function(fit) {
  stopifnot(inherits(fit, "nmf_fit"))
  pct <- 100 * (1 - fit$rel_error)
  list(
    method        = fit$method,
    k_requested   = fit$k_requested,
    k_live        = fit$k_live,
    collapsed     = fit$k_live < fit$k_requested,
    rel_error     = fit$rel_error,
    accuracy_pct  = max(0, min(100, pct)),
    quality       = if (fit$rel_error < 0.05) "good"
                    else if (fit$rel_error < 0.20) "fair"
                    else "poor",
    reproducible  = !is.null(fit$seed)
  )
}

#' Reconstruct the input from the factors
#'
#' Exposed so the app can show an original-vs-reconstructed comparison, and so
#' tests can check the round trip without reaching into W and H.
reconstruct <- function(fit) {
  stopifnot(inherits(fit, "nmf_fit"))
  fit$W %*% fit$H
}
