# The factor-explorer module.
#
# Written as a Shiny module specifically so it is testable. shiny::testServer()
# can drive a module server directly -- setting inputs, reading outputs and
# inspecting returned reactives -- with no browser, no Chrome on the runner
# and no screenshots. That makes it the right tool for the Tier 3 tests that
# gate every push; shinytest2 and a real browser are reserved for the slower
# tier.
#
# The module deliberately holds no business logic. It wires inputs to the
# functions in nmf.R and summarise.R and exposes the result. Anything worth
# asserting about a calculation is asserted in Tier 1 against those functions.

mod_factors_ui <- function(id) {
  ns <- shiny::NS(id)
  shiny::tagList(
    shiny::sidebarLayout(
      shiny::sidebarPanel(
        shiny::sliderInput(ns("k"), "Number of components",
                           min = 1, max = 6, value = 3, step = 1),
        shiny::selectInput(ns("method"), "Algorithm",
                           choices = NMF_METHODS, selected = "nnmf_mm"),
        shiny::numericInput(ns("seed"), "Random seed", value = 1, min = 1),
        shiny::sliderInput(ns("n_top"), "Top features per component",
                           min = 1, max = 8, value = 3, step = 1),
        shiny::actionButton(ns("run"), "Run factorisation",
                            class = "btn-primary")
      ),
      shiny::mainPanel(
        shiny::verbatimTextOutput(ns("status")),
        shiny::plotOutput(ns("loadings_plot")),
        shiny::tableOutput(ns("top_table"))
      )
    )
  )
}

#' @param id Module id.
#' @param data_r A reactive returning the matrix to factorise.
mod_factors_server <- function(id, data_r) {
  shiny::moduleServer(id, function(input, output, session) {

    # The factorisation itself. eventReactive rather than reactive so moving
    # the slider does not fire an expensive refit on every pixel.
    fit_r <- shiny::eventReactive(input$run, {
      x <- data_r()
      validate_nmf_input(x, input$k, input$method)   # throws user-facing text
      nmf_factorise(
        x,
        k = input$k,
        method = input$method,
        maxiter = 500,
        seed = input$seed
      )
    }, ignoreNULL = FALSE)

    # Validation state, recomputed on every input change so the UI can warn
    # before the user presses Run. Returns NULL when the inputs are usable.
    input_error_r <- shiny::reactive({
      x <- data_r()
      tryCatch({
        validate_nmf_input(x, input$k, input$method)
        NULL
      }, error = function(e) conditionMessage(e))
    })

    summary_r <- shiny::reactive({
      fit_summary(fit_r())
    })

    top_r <- shiny::reactive({
      top_features(fit_r(), n_top = input$n_top,
                   feature_names = rownames(data_r()))
    })

    output$status <- shiny::renderText({
      err <- input_error_r()
      if (!is.null(err)) {
        return(paste("Cannot run:", err))
      }
      s <- summary_r()
      lines <- c(
        sprintf("Algorithm:   %s", s$method),
        sprintf("Components:  %d live of %d requested", s$k_live,
                s$k_requested),
        sprintf("Accuracy:    %.1f%% (%s)", s$accuracy_pct, s$quality),
        sprintf("Reproducible: %s", if (s$reproducible) "yes" else "no")
      )
      if (s$collapsed) {
        lines <- c(lines,
                   "Note: some components carry no weight. Try a smaller k.")
      }
      paste(lines, collapse = "\n")
    })

    output$loadings_plot <- shiny::renderPlot({
      d <- tidy_loadings(fit_r(), feature_names = rownames(data_r()))
      if (nrow(d) == 0L) {
        graphics::plot.new()
        graphics::title("No live components to show")
        return(invisible(NULL))
      }
      m <- matrix(d$loading, nrow = length(unique(d$feature)))
      graphics::barplot(m, beside = TRUE,
                        main = "Feature loadings by component",
                        xlab = "Component", ylab = "Loading")
    })

    output$top_table <- shiny::renderTable({
      top_r()
    })

    # Exported so testServer and a parent module can read the state without
    # scraping rendered output.
    list(
      fit = fit_r,
      summary = summary_r,
      top = top_r,
      input_error = input_error_r
    )
  })
}
