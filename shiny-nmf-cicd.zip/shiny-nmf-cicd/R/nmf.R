# The wrapper layer between the app and NMFN.
#
# Nothing in the app calls NMFN::nnmf() directly. Everything goes through
# nmf_factorise(), which exists to fix five things the package leaves open:
#
#   1. No input validation. NMFN does not check that x is non-negative --
#      despite that being the premise of the method -- and nnmf_prob does not
#      check for NA/Inf either.
#   2. No seed control. All three algorithms initialise from rnorm() and take
#      no seed argument, so results are irreproducible unless the caller sets
#      a seed, and setting one leaks into the caller's RNG stream.
#   3. Chatty output. Every algorithm cat()s a progress line every 50
#      iterations. Inside a Shiny reactive that floods the logs.
#   4. Silent method fallback. nnmf()'s dispatch ends in a bare `else` that
#      runs the multiplicative update, so a typo'd method name quietly runs a
#      different algorithm.
#   5. Silent factor collapse. nnmf_als can return all-zero columns, so the
#      caller may get fewer usable components than it asked for.
#
# Everything here is a pure function of its arguments, which is what makes the
# Tier 1 tests fast and deterministic.

NMF_METHODS <- c("nnmf_mm", "nnmf_als", "nnmf_prob")

#' Validate a matrix and settings before factorising
#'
#' Separated from nmf_factorise() so it can be unit tested on its own and
#' reused by the UI to decide whether to enable the Run button.
#'
#' @return TRUE invisibly, or throws with a message meant for an end user.
validate_nmf_input <- function(x, k, method = "nnmf_mm") {
  if (!is.matrix(x)) {
    stop("Data must be a matrix.", call. = FALSE)
  }
  if (!is.numeric(x)) {
    stop("Data must be numeric.", call. = FALSE)
  }
  if (nrow(x) < 1L || ncol(x) < 1L) {
    stop("Data must have at least one row and one column.", call. = FALSE)
  }
  if (any(!is.finite(x))) {
    stop("Data contains missing or infinite values.", call. = FALSE)
  }
  if (any(x < 0)) {
    stop("Data contains negative values. ",
         "Non-negative matrix factorisation requires all values >= 0.",
         call. = FALSE)
  }
  if (sum(x) <= 0) {
    stop("Data sums to zero, so there is nothing to factorise.", call. = FALSE)
  }
  if (length(k) != 1L || is.na(k) || k < 1L || k != as.integer(k)) {
    stop("`k` must be a single positive whole number.", call. = FALSE)
  }
  if (k > min(dim(x))) {
    stop("`k` (", k, ") cannot exceed the smaller matrix dimension (",
         min(dim(x)), ").", call. = FALSE)
  }
  if (length(method) != 1L || !method %in% NMF_METHODS) {
    # NMFN itself would silently run nnmf_mm here.
    stop("Unknown method '", paste(method, collapse = ", "), "'. ",
         "Choose one of: ", paste(NMF_METHODS, collapse = ", "), ".",
         call. = FALSE)
  }
  invisible(TRUE)
}

#' Count factors that carry any weight
#'
#' nnmf_als can zero a whole column of W, leaving a factor that contributes
#' nothing. The returned W still has k columns, so anything downstream that
#' assumes k usable components needs this.
count_live_factors <- function(W, tol = 1e-10) {
  sum(colSums(W) > tol)
}

#' Relative reconstruction error
#'
#' The same scale-free quantity NMFN prints internally as `relative error`.
reconstruction_error <- function(x, W, H) {
  mean(abs(x - W %*% H)) / mean(abs(x))
}

#' Factorise a non-negative matrix, reproducibly
#'
#' @param x Non-negative numeric matrix.
#' @param k Number of components.
#' @param method One of NMF_METHODS.
#' @param maxiter Iteration cap. NMFN only checks convergence every 50
#'   iterations, so values below 50 always run to completion.
#' @param seed Integer or NULL. When supplied, the result is reproducible and
#'   the caller's RNG stream is left untouched.
#'
#' @return An object of class "nmf_fit": a list with W, H, and the metadata
#'   needed to interpret and reproduce the fit.
nmf_factorise <- function(x, k, method = "nnmf_mm", maxiter = 500,
                          seed = NULL) {
  validate_nmf_input(x, k, method)

  if (!is.null(seed)) {
    # Snapshot and restore the RNG, so calling this does not perturb anything
    # else that depends on the random stream. Without this, a factorisation
    # inside a Shiny reactive would silently change unrelated sampling
    # elsewhere in the session.
    if (exists(".Random.seed", envir = globalenv())) {
      old_seed <- get(".Random.seed", envir = globalenv())
      on.exit(assign(".Random.seed", old_seed, envir = globalenv()),
              add = TRUE)
    } else {
      on.exit(suppressWarnings(rm(".Random.seed", envir = globalenv())),
              add = TRUE)
    }
    set.seed(seed)
  }

  # NMFN prints unconditionally; capture.output is the only way to silence it.
  logs <- utils::capture.output(
    fit <- NMFN::nnmf(x, k, method = method, maxiter = maxiter)
  )

  live <- count_live_factors(fit$W)
  if (live < k) {
    warning("Requested ", k, " factors but only ", live,
            " carry any weight. This usually means `k` exceeds the structure ",
            "present in the data.", call. = FALSE)
  }

  structure(
    list(
      W = fit$W,
      H = fit$H,
      k_requested = as.integer(k),
      k_live = as.integer(live),
      method = method,
      maxiter = as.integer(maxiter),
      seed = seed,
      rel_error = reconstruction_error(x, fit$W, fit$H),
      dim_x = dim(x),
      nmfn_version = as.character(utils::packageVersion("NMFN")),
      iterations_logged = length(grep("Iter =", logs))
    ),
    class = "nmf_fit"
  )
}

#' @export
print.nmf_fit <- function(x, ...) {
  cat("<nmf_fit>", x$method, "\n")
  cat("  input:      ", paste(x$dim_x, collapse = " x "), "\n")
  cat("  factors:    ", x$k_live, "live of", x$k_requested, "requested\n")
  cat("  rel. error: ", signif(x$rel_error, 4), "\n")
  cat("  seed:       ", if (is.null(x$seed)) "none (not reproducible)"
      else x$seed, "\n")
  invisible(x)
}
