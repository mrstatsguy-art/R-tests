# Shiny + NMFN with a CI-grade test suite

A working example of the test layering an R Shiny app needs to be safe to
deploy automatically: a small component-explorer app that factorises a
feature-by-sample matrix with [NMFN](https://cran.r-project.org/package=NMFN),
and 86 tests arranged in three tiers behind two GitHub Actions workflows.

It is a **template to map onto your own app**, not a library to depend on. The
app is deliberately small; the structure around it is the point.

```bash
Rscript ci/run-tests.R          # the push gate
```

Read [TESTING.md](TESTING.md) for the strategy and the reasoning. That is the
part worth your time.

---

## Layout

```
app.R                     entry point; ends with shinyApp(), never runApp()
R/
  nmf.R                   the wrapper around NMFN: validation, seeding, warnings
  summarise.R             loadings -> tidy data for charts and tables
  data.R                  synthetic fixtures and CSV parsing
  mod_factors.R           the Shiny module (a module so testServer can drive it)
tests/testthat/
  helper-00-load-app.R    makes R/ available to the tests
  helper-fixtures.R       fixtures, measured thresholds, tier helpers
  test-unit-*.R           Tier 1: your code. Fast, exact. Gates merges
  test-contract-nmfn.R    Tier 2: the dependency. Advisory, does not gate
  test-system-*.R         Tier 3: the app. Headless gates; browser is nightly
ci/
  run-tests.R             tier runner, JUnit output, correct exit codes
  flake-hunt.R            repeats the gate; re-measures thresholds
.github/workflows/
  ci.yml                  push gate: unit -> system, contract advisory
  nightly.yml             browser tests + flake hunt at 03:17
```

---

## The three ideas worth copying

**1. Separate "my code broke" from "my dependency changed."** Tier 2 tests
NMFN's behaviour and runs as its own advisory job. Collapse that distinction
into one suite and a vendor behaviour change blocks every unrelated fix in the
repository — after which people learn to merge through red, and the pipeline
stops meaning anything.

**2. Measure every tolerance before you assert it.** One threshold in the
obvious first draft (`nnmf_als` recovery `< 0.05`) turned out to fail **9.3% of
the time** across 300 random starts. That is a spurious red build every
eleventh push. Three hundred runs of a numpy port found it before it reached
CI; `ci/flake-hunt.R` keeps checking nightly.

**3. `shiny::testServer()` before `shinytest2`.** It drives a module server
with a mock session — no browser, no Chrome on the runner, no screenshots that
drift when fonts differ between your laptop and the server. Fast enough to gate
every push. Keep the real browser for a nightly job.

---

## Mapping this onto your app

In rough order of value:

1. **Move business logic out of `server()` into `R/`.** Worth more than every
   test in this repo. Logic in a plain function is testable in milliseconds;
   the same logic in a reactive needs a mock session or a browser.
2. **Wrap your risky dependency.** `R/nmf.R` shows the shape: validate inputs,
   control the seed, suppress chatter, surface what the package hides. One
   wrapper, one place to test, one place to fix.
3. **Convert the app to modules** so `testServer()` can reach the server logic.
4. **Copy `ci/run-tests.R`** — tier filters, JUnit output, and a non-zero exit
   on failure. `testthat` alone prints failures and exits 0, so a pipeline using
   it naively reports green while the tests are red.
5. **Adopt the tier split** in `ci.yml` and leave Tier 2 out of branch
   protection.

The example app's `demo_matrix()` stands in for whatever your app loads. If
yours reads from a database, keep the query in one function, test the
transformation on synthetic rows, and leave the connection to the system tier.

---

## Requirements

- R, `shiny`, `NMFN`, `testthat` (>= 3.0)
- `MASS` optional, used by one contract test
- `shinytest2` and Chrome for the browser tier only

Fixtures are synthetic by design, never samples of real data: CI logs, failure
output and snapshot files are all readable by anyone with repository access.

---

## Caveat

The suite has not been executed. It was written against the NMFN source, which
I read in full, and every mathematical claim in it was verified numerically —
but by porting the three algorithms to Python/numpy, because the environment it
was written in has no R and no way to install one.

So the **assertions are verified** and the **R syntax is not**: delimiters
balance and the idioms are standard, but nothing has been through an R parser.
Budget one pass for typos. The likeliest spots are the error-message regexps in
`test-unit-validate.R` and the `testServer()` calls in `test-system-server.R`,
whose `args =` form depends on your Shiny version.
